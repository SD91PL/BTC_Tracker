import { colors, monoFont } from '../../theme'
import { NA } from '../../constants'

// Header shows 2 decimals; tooltip shows full precision on hover.
const DISPLAY_DECIMALS = 2
const PRECISE_DECIMALS = 6

interface ExchangeRateFooterProps {
	hasRate: boolean
	usdPlnRate: number | null
}

export function ExchangeRateFooter({
	hasRate,
	usdPlnRate,
}: ExchangeRateFooterProps) {
	return (
		<div className='px-3 pb-4.5 text-center'>
			<button className='relative inline-block px-3 py-1 group'>
				<p
					className='text-xs cursor-help'
					style={{ color: colors.textFaint, fontFamily: monoFont }}>
					1 USD = {hasRate ? usdPlnRate!.toFixed(DISPLAY_DECIMALS) : NA} PLN
				</p>

				{hasRate && (
					<div
						className='pointer-events-none absolute bottom-full left-1/2 -translate-x-1/2 mb-2
							opacity-0 group-hover:opacity-100 group-focus-within:opacity-100 transition-opacity duration-150 whitespace-nowrap z-10'>
						<div
							style={{
								background: 'rgba(var(--color-bg-rgb), 0.9)',
								border: '0.0625rem solid rgba(var(--color-bitcoin-rgb), 0.3)',
								backdropFilter: 'blur(0.75rem)',
							}}
							className='px-3 py-1.5 rounded-lg'>
							<p
								style={{ color: colors.mint, fontFamily: monoFont }}
								className='text-[0.6875rem]'>
								1 USD = {usdPlnRate!.toFixed(PRECISE_DECIMALS)} PLN
							</p>
						</div>
					</div>
				)}
			</button>
		</div>
	)
}
