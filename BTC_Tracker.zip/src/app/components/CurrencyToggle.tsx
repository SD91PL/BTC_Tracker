import { useEffect, useRef, useState } from 'react'
import { colors, monoFont } from '../../theme'
import { CURRENCY_TOGGLE_DELAY_MS } from '../../constants'
import { useAppDispatch, useAppSelector } from '../../store/hooks'
import {
	toggleStarted,
	toggleCommitted,
} from '../../store/slices/currencySlice'

export function CurrencyToggle() {
	const dispatch = useAppDispatch()
	const currency = useAppSelector(state => state.currency.currency)

	const [displayCurrency, setDisplayCurrency] = useState(currency)

	const [iconRotation, setIconRotation] = useState(0)
	const [isAnimating, setIsAnimating] = useState(false)

	const resetTimer = useRef<ReturnType<typeof setTimeout> | null>(null)

	// Syncs the local display value with Redux when it changes externally
	// (e.g. the reset button snapping currency back to USD).
	useEffect(() => {
		setDisplayCurrency(currency)
	}, [currency])

	function handleToggle() {
		const next = displayCurrency === 'USD' ? 'PLN' : 'USD'

		setDisplayCurrency(next)

		if (resetTimer.current) {
			clearTimeout(resetTimer.current)
		}

		setIsAnimating(true)
		setIconRotation(180)

		resetTimer.current = setTimeout(() => {
			setIsAnimating(false)
			setIconRotation(0)
		}, 350)

		dispatch(toggleStarted())

		setTimeout(() => {
			dispatch(toggleCommitted())
		}, CURRENCY_TOGGLE_DELAY_MS)
	}

	return (
		// Fixed width, centered — stays a stable tap target as the card widens.
		<div className='px-6 py-5 flex justify-center'>
			<button
				onClick={handleToggle}
				className='relative w-full max-w-[21rem] overflow-hidden cursor-pointer'
				style={{ borderRadius: '0.75rem' }}>
				{/* USD gradient */}
				<div
					className='absolute inset-0'
					style={{
						borderRadius: '0.75rem',
						background:
							'linear-gradient(135deg, rgba(var(--color-mint-rgb), 0.6), rgba(var(--color-amber-rgb), 0.2))',
						opacity: displayCurrency === 'USD' ? 1 : 0,
						transition: 'opacity .4s ease',
					}}
				/>

				{/* PLN gradient */}
				<div
					className='absolute inset-0'
					style={{
						borderRadius: '0.75rem',
						background:
							'linear-gradient(135deg, rgba(var(--color-indigo-rgb), 0.6), rgba(var(--color-violet-rgb), 0.2))',
						opacity: displayCurrency === 'PLN' ? 1 : 0,
						transition: 'opacity .4s ease',
					}}
				/>

				{/* Inner panel */}
				<div
					className='absolute inset-[0.0625rem]'
					style={{
						borderRadius: '0.6875rem',
						background: 'rgba(var(--color-bg-rgb), 0.6)',
						backdropFilter: 'blur(0.5rem)',
						WebkitBackdropFilter: 'blur(0.5rem)',
					}}
				/>

				{/* Content */}
				<div className='relative flex items-center justify-between px-5 py-3.5'>
					{/* USD */}
					<div className='flex items-center gap-2'>
						<div className='relative w-6 h-6 rounded-full overflow-hidden'>
							<div
								className='absolute inset-0'
								style={{
									background: 'rgba(var(--color-surface-rgb), 0.08)',
									opacity: displayCurrency === 'USD' ? 0 : 1,
									transition: 'opacity .3s ease',
								}}
							/>

							<div
								className='absolute inset-0'
								style={{
									background: `linear-gradient(135deg, ${colors.mint}, ${colors.mintDark})`,
									opacity: displayCurrency === 'USD' ? 1 : 0,
									transition: 'opacity .3s ease',
								}}
							/>

							<span
								className='relative flex items-center justify-center w-full h-full text-xs font-bold'
								style={{
									color:
										displayCurrency === 'USD'
											? 'rgb(var(--color-on-mint-rgb))'
											: colors.textMuted,
									fontFamily: monoFont,
								}}>
								$
							</span>
						</div>

						<span
							className='text-sm font-medium transition-colors duration-300'
							style={{
								color:
									displayCurrency === 'USD' ? colors.mint : colors.textMuted,
								fontFamily: monoFont,
							}}>
							USD
						</span>
					</div>

					{/* Icon */}
					<svg
						width='16'
						height='16'
						viewBox='0 0 16 16'
						fill='none'
						style={{
							color: colors.textMuted,
							transform: `rotate(${iconRotation}deg)`,
							transformOrigin: 'center',
							transition: isAnimating ? 'transform 350ms ease' : 'none',
						}}>
						<path
							d='M3 5l3-3 3 3M6 2v8M13 11l-3 3-3-3M10 14V6'
							stroke='currentColor'
							strokeWidth='1.5'
							strokeLinecap='round'
							strokeLinejoin='round'
						/>
					</svg>

					{/* PLN */}
					<div className='flex items-center gap-2'>
						<span
							className='text-sm font-medium transition-colors duration-300'
							style={{
								color:
									displayCurrency === 'PLN'
										? colors.indigoLight
										: colors.textMuted,
								fontFamily: monoFont,
							}}>
							PLN
						</span>

						<div className='relative w-6 h-6 rounded-full overflow-hidden'>
							<div
								className='absolute inset-0'
								style={{
									background: 'rgba(var(--color-surface-rgb), 0.08)',
									opacity: displayCurrency === 'PLN' ? 0 : 1,
									transition: 'opacity .3s ease',
								}}
							/>

							<div
								className='absolute inset-0'
								style={{
									background: `linear-gradient(135deg, ${colors.indigo}, ${colors.indigoLight})`,
									opacity: displayCurrency === 'PLN' ? 1 : 0,
									transition: 'opacity .3s ease',
								}}
							/>

							<span
								className='relative flex items-center justify-center w-full h-full text-xs font-bold'
								style={{
									color:
										displayCurrency === 'PLN'
											? 'rgb(var(--color-on-accent-rgb))'
											: colors.textMuted,
									fontFamily: monoFont,
								}}>
								zł
							</span>
						</div>
					</div>
				</div>
			</button>
		</div>
	)
}
