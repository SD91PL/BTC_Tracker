import { useAppDispatch, useAppSelector } from '../../store/hooks'
import { themeToggled } from '../../store/slices/themeSlice'
import { colors } from '../../theme'

// Track/thumb geometry, in rem so it scales with root font-size.
const TRACK_WIDTH = 4.5 // 72px
const TRACK_HEIGHT = 2.25 // 36px
const THUMB_SIZE = 1.75 // 28px
const THUMB_INSET = (TRACK_HEIGHT - THUMB_SIZE) / 2 // 0.25rem / 4px

export function ThemeToggle() {
	const dispatch = useAppDispatch()
	const mode = useAppSelector(state => state.theme.mode)
	const isDark = mode === 'dark'

	return (
		<button
			onClick={() => dispatch(themeToggled())}
			aria-label={
				isDark ? 'Switch to light theme' : 'Switch to dark theme'
			}
			aria-pressed={isDark}
			className='relative cursor-pointer group'
			style={{
				width: `${TRACK_WIDTH}rem`,
				height: `${TRACK_HEIGHT}rem`,
				borderRadius: '62.4375rem',
				padding: '0.0625rem',
				background:
					'linear-gradient(135deg, rgba(var(--color-mint-rgb), 0.55) 0%, rgba(var(--color-indigo-rgb), 0.45) 100%)',
				transition: 'background 0.4s ease',
			}}>
			{/* Glass track */}
			<div
				className='relative w-full h-full overflow-hidden'
				style={{
					borderRadius: '62.4375rem',
					background: 'rgba(var(--color-bg-elevated-rgb), 0.6)',
					backdropFilter: 'blur(1rem)',
					WebkitBackdropFilter: 'blur(1rem)',
					transition: 'background 0.4s ease',
				}}>
				{/* Sun icon */}
				<span
					className='absolute top-1/2 flex items-center justify-center transition-opacity duration-300'
					style={{
						left: `${THUMB_INSET + 0.0625}rem`,
						width: `${THUMB_SIZE - 0.5}rem`,
						height: `${THUMB_SIZE - 0.5}rem`,
						transform: 'translateY(-50%)',
						color: colors.textFaint,
						opacity: isDark ? 0.5 : 0,
					}}>
					<SunIcon />
				</span>

				{/* Moon icon */}
				<span
					className='absolute top-1/2 flex items-center justify-center transition-opacity duration-300'
					style={{
						right: `${THUMB_INSET + 0.0625}rem`,
						width: `${THUMB_SIZE - 0.5}rem`,
						height: `${THUMB_SIZE - 0.5}rem`,
						transform: 'translateY(-50%)',
						color: colors.textFaint,
						opacity: isDark ? 0 : 0.5,
					}}>
					<MoonIcon />
				</span>

				{/* Sliding thumb */}
				<span
					className='absolute top-1/2 rounded-full flex items-center justify-center'
					style={{
						width: `${THUMB_SIZE}rem`,
						height: `${THUMB_SIZE}rem`,
						left: isDark
							? `${TRACK_WIDTH - THUMB_SIZE - THUMB_INSET}rem`
							: `${THUMB_INSET}rem`,
						transform: 'translateY(-50%)',
						background: isDark
							? `linear-gradient(135deg, ${colors.indigo}, ${colors.indigoLight})`
							: `linear-gradient(135deg, ${colors.mint}, ${colors.mintDark})`,
						boxShadow: isDark
							? '0 0.125rem 0.625rem rgba(var(--color-indigo-rgb), 0.5)'
							: '0 0.125rem 0.625rem rgba(var(--color-mint-rgb), 0.5)',
						transition:
							'left 0.35s cubic-bezier(0.34, 1.3, 0.64, 1), background 0.35s ease, box-shadow 0.35s ease',
					}}>
					<span
						key={mode}
						className='flex items-center justify-center'
						style={{
							width: `${THUMB_SIZE - 0.625}rem`,
							height: `${THUMB_SIZE - 0.625}rem`,
							// Moon: on-accent white; sun: on-mint (flips per theme).
							color: isDark
								? 'rgb(var(--color-on-accent-rgb))'
								: 'rgb(var(--color-on-mint-rgb))',
							animation: 'theme-toggle-pop 0.35s ease',
						}}>
						{isDark ? <MoonIcon filled /> : <SunIcon filled />}
					</span>
				</span>
			</div>
		</button>
	)
}

function SunIcon({ filled = false }: { filled?: boolean }) {
	return (
		<svg
			width='100%'
			height='100%'
			viewBox='0 0 16 16'
			fill='none'>
			<circle
				cx='8'
				cy='8'
				r='3.5'
				fill={filled ? 'currentColor' : 'none'}
				stroke='currentColor'
				strokeWidth='1.5'
			/>
			<path
				d='M8 0.5v2M8 13.5v2M15.5 8h-2M2.5 8h-2M13.4 2.6l-1.4 1.4M4 12l-1.4 1.4M13.4 13.4L12 12M4 4L2.6 2.6'
				stroke='currentColor'
				strokeWidth='1.5'
				strokeLinecap='round'
			/>
		</svg>
	)
}

function MoonIcon({ filled = false }: { filled?: boolean }) {
	return (
		<svg
			width='100%'
			height='100%'
			viewBox='0 0 16 16'
			fill='none'>
			<path
				d='M14 9.7A6.3 6.3 0 1 1 6.3 2a5 5 0 0 0 7.7 7.7Z'
				fill={filled ? 'currentColor' : 'none'}
				stroke='currentColor'
				strokeWidth='1.5'
				strokeLinejoin='round'
			/>
		</svg>
	)
}
